import os, sys
sys.dont_write_bytecode = True
if sys.argv and sys.argv[0] and sys.argv[0] not in ("-c", "-m"):
    sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
